# Interactive Map HTML Code 

A Pen created on CodePen.

Original URL: [https://codepen.io/DrManlio-Ceroni/pen/gbPWpLK](https://codepen.io/DrManlio-Ceroni/pen/gbPWpLK).

Desarrollo con Codigo HTML  de mapa mental interactivo de Estrategias de Desarrollo de Productos y Mercado. Elaborado por: Dr. Manlio Ceroni 